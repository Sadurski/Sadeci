$(document).on('ready', function() {

	var NickBox = function(productClass, hideDelay, showDelay) {

		var blackout  = $(".blackout");
		var black     = $(".black");
		var container = ".container";
		var image     = $(productClass);

		black.on('click', function() {

			blackout.fadeOut(hideDelay, function() {
				$(this).hide();

				blackout.find(container).hide();
			});

			$(this).hide();

		});

		$(image).on('click', function() {

			var id = $(this).data("id");
			black.show();
			blackout.find(container).hide();
			$(id).show();

			blackout.find(container).find("img").on('click', function() {
				blackout.fadeOut(hideDelay, function() {
					blackout.find(container).hide();
					blackout.hide();
				});
			});

			blackout.fadeIn(showDelay);

		});
	
	};

	NickBox('.nickbox', 300, 400);

});