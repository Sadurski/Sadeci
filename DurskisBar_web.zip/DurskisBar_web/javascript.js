// JavaScript Document

$(document).ready(function() {
 
  $("#demo").owlCarousel({
 
      autoPlay: 3000, //Set AutoPlay to 3 seconds
 
      items : 6,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3]
 
  });
 
});

/*SCROLL*/

$(window).scroll(function(){
	var wScroll = $(this).scrollTop();
	var nav = $('.nav');
	var section = $("#cocktail");
	var wHeight = $(window).height();
		if (wScroll >= wHeight) {
			 nav.addClass('fixed');
			 section.addClass('fixed');
		} else {
			nav.removeClass('fixed');
			section.removeClass('fixed');
		}
});

/*NICE-SCROLL*/

$(".a-1").click(function (e) {
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $("body").offset().top - 50
      }, 1000);
});

$(".a-2").click(function (e) {
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $(".cocktail").offset().top - 50
      }, 1000);
});

$(".a-3").click(function (e) {
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $("#menu").offset().top - 50
      }, 1000);
});

$(".a-4").click(function (e) {
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $("#event").offset().top - 50
      }, 1000);
});

$(".a-5").click(function (e) {
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $("#findos").offset().top - 50
      }, 1000);
});

$(".a-6").click(function (e) {
    e.preventDefault();
    $('html, body').animate({
        scrollTop: $("#demo").offset().top - 50
      }, 1000);
});

/*PLANNING*/

$("#planning_form").submit(function(e) {
	
	e.preventDefault();
	
	var AntalFejl = 0;
	var FejlBesked1 = "";
	var FejlBesked2 = "";
	var FejlBesked3 = "";
	
	if( document.getElementById( 'name' ).value == "" )
	{	
		AntalFejl += 1;
		FejlBesked1 = "Skriv dit navn!";
	}
	else
	{
		var regexpbogstaver = /^[a-zA-Z ]+$/;
		if( !regexpbogstaver.test( document.getElementById('name').value ) )
		{
			AntalFejl += 1;
			FejlBesked1 = "Navn må kun indeholde bogstaver og mellemrum!";
		}
	}
	
	
	if( document.getElementById( 'email' ).value == "" )
	{
		AntalFejl += 1;
		FejlBesked2 = "Du skal skrive din mail!";
	}
	else
	{
		var regexpmail = /^[A-Za-zÆØÅæøå0-9_.]+[@]{1}[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
		if( !regexpmail.test( document.getElementById('email').value ) )
		{
			AntalFejl += 1;
			FejlBesked2 = "Mail er ikke gyldig!";
		}
	}
	
	if( AntalFejl == 0 )
	{
		$(".blackout").hide();
		return false;
	}
	else
	{
		document.getElementById( 'FejlBesked1' ).innerHTML = FejlBesked1;
		document.getElementById( 'FejlBesked2' ).innerHTML = FejlBesked2;
		return false;
	}
	
});

/*DURSKISBAR*/

$("#durskisbar_form").submit(function(e) {

	e.preventDefault();

	var AntalFejl = 0;
	var Fejl1 = "";
	var Fejl2 = "";
	
	if( document.getElementById( 'navn' ).value == "" )
	{	
		AntalFejl += 1;
		Fejl1 = "Skriv dit navn!";
	}
	else
	{
		var regexpbogstaver = /^[a-zA-Z ]+$/;
		if( !regexpbogstaver.test( document.getElementById('navn').value ) )
		{
			AntalFejl += 1;
			Fejl1 = "Navn må kun indeholde bogstaver og mellemrum!";
		}
	}
	
	
	if( document.getElementById( 'email' ).value == "" )
	{
		AntalFejl += 1;
		Fejl2 = "Du skal skrive din mail!";
	}
	else
	{
		var regexpmail = /^[A-Za-zÆØÅæøå0-9_.]+[@]{1}[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
		if( !regexpmail.test( document.getElementById('email').value ) )
		{
			AntalFejl += 1;
			Fejl2 = "Mail er ikke gyldig!";
		}
	}
	
	if( AntalFejl == 0 )
	{
		$(".blackout").hide();
		return false;
	}
	else
	{
		document.getElementById( 'Fejl1' ).innerHTML = Fejl1;
		document.getElementById( 'Fejl2' ).innerHTML = Fejl2;
		return false;
	}
	
});

/*FINDOS*/

$("#findos_form").submit(function(e) {

	e.preventDefault();
	
	var AntalFejl = 0;
	var fuck1 = "";
	var fuck2 = "";
	
	if( document.getElementById( 'navn' ).value == "" )
	{	
		AntalFejl += 1;
		fuck1 = "Skriv dit navn!";
	}
	else
	{
		var regexpbogstaver = /^[a-zA-Z ]+$/;
		if( !regexpbogstaver.test( document.getElementById('navn').value ) )
		{
			AntalFejl += 1;
			fuck11 = "Navn må kun indeholde bogstaver og mellemrum!";
		}
	}
	
	
	if( document.getElementById( 'email' ).value == "" )
	{
		AntalFejl += 1;
		fuck2 = "Du skal skrive din mail!";
	}
	else
	{
		var regexpmail = /^[A-Za-zÆØÅæøå0-9_.]+[@]{1}[a-zA-Z_]+?\.[a-zA-Z]{2,3}$/;
		if( !regexpmail.test( document.getElementById('email').value ) )
		{
			AntalFejl += 1;
			fuck2 = "Mail er ikke gyldig!";
		}
	}
	
	if( AntalFejl == 0 )
	{
		$(".blackout").hide();
		return false;
	}
	else
	{
		document.getElementById( 'fuck1' ).innerHTML = fuck1;
		document.getElementById( 'fuck2' ).innerHTML = fuck2;
		return false;
	}
	
});